import camelot
from tkinter import *
from tkinter.filedialog import askopenfilename

##############################################################
                        #DESIGN PART
##############################################################

filename = ""
def extraction():
    global filename

#GUI Part Starts
    window = Tk()
    window.title("TABLE EXTRACTOR")
    window.configure(bg='#FFFF00')
    window.iconbitmap(r'icon.ico')
    window.geometry('500x300')


#Message File lable and button
    lb0= Label(window, text="WELCOME TO EXTRACTOR",font=('Gothic bold',20),bg='#FFFF00')
    lb0.grid(column=0, row=0)
    lbl = Label(window, text="Choose Your PDF File",font=('Gothic bold',14),bg='#FFFF00')
    lbl.grid(column=0, row=1)
    def clicked():
        global filename
        filename = askopenfilename()
        lbl.configure(text="You have choosed "+filename.split('/')[-1])
    btn = Button(window, text="Choose File", command=clicked,bg='#89CFF0',padx=5,pady=5)
    btn.grid(column=1, row=1)

#filetype
    lb2 = Label(window, text="Choice of Convertion",font=('Gothic bold',14),bg='#FFFF00')
    lb2.grid(column=0, row=3)
    choice=StringVar()
    choice.set("choose")
    d=OptionMenu(window,choice,"ALL","EXCEL","CSV","JSON","SQL","HTML")
    d.configure(bg='#89CFF0',padx=5,pady=5)
    d.grid(column=1, row=3)



#Submit
    def clicked():
        window.destroy()  
    btn3 = Button(window, text="Start Extraction", command=clicked)
    btn3.configure(bg='#89CFF0',padx=8,pady=8)
    btn3.grid(column=0, row=6)
    window.mainloop()


#GUI Part Ends


    FILE_PATH = filename
    print(FILE_PATH)
    
##########################################################################


    tables = camelot.read_pdf(FILE_PATH,pages="all",flavor="stream")

    if(choice.get()=="EXCEL"):
        def convert2excel(tables):
            tables.export("outxl.xlsx", f="excel", compress=True)
        convert2excel(tables)
        print('\n',filename,'converted to Excel file')
    elif(choice.get()=="CSV"):
        def convert2csv(tables):
            tables.export("outcsv.csv", f="csv", compress=True)
        convert2csv(tables)
        print('\n',filename,'converted to CSV file')
    elif(choice.get()=="JSON"):
        def convert2json(tables):
            tables.export("outjson.json", f="json", compress=True)
        convert2json(tables)
        print('\n',filename,'converted to JSON file')
    elif(choice.get()=="HTML"):
        def convert2html(tables):
            tables.export("outhtml.html", f="html", compress=True)
        convert2html(tables)
        print('\n',filename,'converted to HTML file')
    elif(choice.get()=="SQL"):
        def convert2sql(tables):
            tables.export("outsql.sql", f="sqlite", compress=True)
        convert2sql(tables)
        print('\n',filename,'converted to SQL file')
    elif(choice.get()=="ALL"):
        def convert2all(tables):
            tables.export("outxl.xlsx", f="excel", compress=True)
            tables.export("outcsv.csv", f="csv", compress=True)
            tables.export("outjson.json", f="json", compress=True)
            tables.export("outhtml.html", f="html", compress=True)
            tables.export("outsql.sql", f="sqlite", compress=True)
        convert2all(tables)
        print('\n',filename,'converted to Excel,CSV,JSON,HTML,SQL files')
extraction()
#confirmation
print("*****COMPLETED*****")

window2 = Tk()
window2.title("TABLE EXTRACTOR")
window2.configure(bg='#FFFF00')
window2.iconbitmap(r'icon.ico')
window2.geometry('400x200')

lb3= Label(window2, text=" COMPLETED EXTRACTION ",font=('Gothic bold',20),bg='#FFFF00')
lb3.grid(column=0, row=0)
lb4 = Label(window2, text=" Want to EXTRACT once again...?",font=('Gothic bold',14),bg='#FFFF00')
lb4.grid(column=0,row=1)
def clicked():
    window2.destroy()
    extraction()
Btn = Button(window2, text="  Repeat  ", command=clicked)
Btn.configure(bg='#89CFF0',padx=5,pady=5)
Btn.grid(column=0, row=2)
def clicked():
    window2.destroy()
Btn2= Button(window2, text="  Cancel  ", command=clicked)
Btn2.configure(bg='#89CFF0',padx=5,pady=5)
Btn2.grid(column=0, row=4)



